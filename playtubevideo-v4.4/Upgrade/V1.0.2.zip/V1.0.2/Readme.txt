PlayTubeVideo v1.0.2 Upgrade Documentation

Note: This update is just for who is using 1.0.1, if you're still using older verisons, Please Upgrade the script version by version.

- Take backup of everything before performing below steps.
- Run "playtubevideo.sql" on your database.
- Upload and overwrite ALL file(s) located inside "script" folder to your server.
- Note: Don't run "playtubevideo.sql" file till all the files are uploaded.
- Run build command again and restart your server.
- Refresh your page, Done!

if you're facing any problems, please contact us so we can help.

SoftwareServitium
softwareservitium@gmail.com
http://www.playtubevideo.com

Copyright © 2020 PlayTubeVideo All rights reserved