INSERT IGNORE INTO `notificationtypes` ( `type`, `body`, `content_type`, `vars`) VALUES
( 'openai_description_create', 'Create content description using OpenAI.', 'default', '{}'),
( 'openai_image_create', 'Create image using OpenAI.', 'default', '{}');

INSERT IGNORE INTO `settings` (`name`, `value`) VALUES
  ("openai_api_key",''),
  ("openai_model",'gpt-3.5-turbo'),
  ("openai_image_system",'1'),
  ("openai_blog_system",'1'),
  ("openai_blog_price",'0.5'),
  ("openai_description_system",'1'),
  ("openai_image_price",'0.2'),
  ("openai_blog_description_count",'1000'),
  ("openai_description_price",'0.1');

  INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'imagecreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'imagecreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

  INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'blogcreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'blogcreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

  INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'descriptioncreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'openai' as `type`,
    'descriptioncreate' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

CREATE TABLE IF NOT EXISTS `user_avtar_images` (
  `avtar_id` int(10) UNSIGNED NOT NULL auto_increment,
  `path` varchar(255) NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT 1,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`avtar_id`),
  KEY `type` (`type`),
  KEY `enable` (`enable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;