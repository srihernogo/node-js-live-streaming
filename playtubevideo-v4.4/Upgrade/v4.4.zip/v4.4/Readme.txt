PlayTubeVideo v4.4 Upgrade Documentation

Note: This update is just for who is using 4.3, if you're still using older verisons, Please Upgrade the script version by version.

- Take backup of everything before performing below steps.
- Upload and overwrite ALL file(s) located inside "script" folder to your server.
- Run all mysql queries from playtubevideo.sql file in your database.
- Run npm install
~ Remove node_modules and package-lock.json file.
- Run build command again "npm execute" and restart your server.
- Refresh your page, Done!

if you're facing any problems, please contact us so we can help.

SoftwareServitium
softwareservitium@gmail.com
SKYPE: softwareservitium@gmail.com
https://www.playtubevideo.com

Copyright © 2020 PlayTubeVideo All rights reserved