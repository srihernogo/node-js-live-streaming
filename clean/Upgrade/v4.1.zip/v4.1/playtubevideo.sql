CREATE TABLE `user_blocks` (
  `block_id` int(11) UNSIGNED NOT NULL auto_increment,
  `owner_id` int(11) unsigned NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `subject_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`block_id`),
  UNIQUE KEY `resource_owner_id` (`resource_id`,`owner_id`),
  KEY `owner_id` (`owner_id`),
  KEY `resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
ALTER TABLE `packages` ADD `apple_id` VARCHAR(255) NULL;
ALTER TABLE `subscriptions` ADD `receipt` TEXT NULL;
INSERT IGNORE INTO `tasks` ( `type`, `started`, `start_time`, `timeout`, `priority`) VALUES
('walletPaymentChannels',0,NULL,15,1),
('userPlanExpiry',0,NULL,15,1);
ALTER TABLE `subscriptions` CHANGE `expiration_date` `expiration_date` DATETIME NULL DEFAULT NULL;
UPDATE `tasks` SET `timeout` = '250',`priority` = "1" WHERE `tasks`.`type` = 'userDowngrade';
INSERT INTO `emailtemplates` ( `content_type`, `type`, `vars`) VALUES
( 'default', 'user_subscribe_payment_subscription_active', NULL),
( 'default', 'user_subscribe_payment_subscription_pending', NULL),
( 'default', 'user_subscribe_payment_subscription_overdue', NULL),
( 'default', 'user_subscribe_payment_subscription_refunded', NULL),
( 'default', 'user_subscribe_payment_subscription_expired', NULL),
( 'default', 'user_subscribe_payment_subscription_recurrence', NULL),
( 'default', 'user_subscribe_payment_subscription_cancelled', NULL),
( 'default', 'user_subscribe_payment_subscription_disputeclear', NULL),
( 'default', 'user_subscribe_payment_subscription_disputecreate', NULL);
ALTER TABLE `movie_videos` CHANGE `title` `title` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL;