CREATE TABLE `currencies` (
  `currency_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `symbol` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `currency_value` float NOT NULL DEFAULT 0,
  `default` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `order` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `gateway_allowed` TEXT DEFAULT NULL,
   PRIMARY KEY (`currency_id`),
   KEY `ID` (`ID`),
   KEY `symbol` (`symbol`),
   KEY `default` (`default`),
   KEY `active` (`active`),
   KEY `order` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `currencies` (`currency_id`, `ID`, `symbol`, `currency`, `currency_value`, `default`, `active`, `order`, `gateway_allowed`) VALUES 
(NULL, 'USD', '$', 'United States dollar', '1', '0', '1', '0', NULL),
(NULL, 'MNT', '₮', 'Mongolian Tugrug', '1', '0', '1', '0', NULL),
(NULL, 'AUD', 'A$', 'Australian dollar', '1', '0', '1', '0', NULL),
(NULL, 'CAD', 'CA$', 'Canadian dollar', '1', '0', '1', '0', NULL),
(NULL, 'CZK', 'CZK', 'Czech koruna', '1', '0', '1', '0', NULL),
(NULL, 'DKK', 'DKK', 'Danish krone', '1', '0', '1', '0', NULL),
(NULL, 'EUR', '€', 'Euro', '1', '0', '1', '0', NULL),
(NULL, 'HKD', 'HK$', 'Hong Kong dollar', '1', '0', '1', '0', NULL),
(NULL, 'ILS', '₪', 'Israeli new shekel', '1', '0', '1', '0', NULL),
(NULL, 'MXN', 'MX$', 'Mexican peso', '1', '0', '1', '0', NULL),
(NULL, 'NZD', 'NZ$', 'New Zealand dollar', '1', '0', '1', '0', NULL),
(NULL, 'NOK', 'NOK', 'Norwegian krone', '1', '0', '1', '0', NULL),
(NULL, 'PHP', '₱', 'Philippine peso', '1', '0', '1', '0', NULL),
(NULL, 'PLN', 'PLN', 'Polish złoty', '1', '0', '1', '0', NULL),
(NULL, 'GBP', '£', 'Pound sterling', '1', '0', '1', '0', NULL),
(NULL, 'RUB', 'RUB', 'Russian ruble', '1', '0', '1', '0', NULL),
(NULL, 'SGD', 'SGD', 'Singapore dollar', '1', '0', '1', '0', NULL),
(NULL, 'SEK', 'SEK', 'Swedish krona', '1', '0', '1', '0', NULL),
(NULL, 'CHF', 'CHF', 'Swiss franc', '1', '0', '1', '0', NULL),
(NULL, 'THB', '฿', 'Thai baht', '1', '0', '1', '0', NULL),
(NULL, 'INR', '₹', 'Indian rupee', '1', '0', '1', '0', NULL);

UPDATE currencies SET `default` = 1 WHERE ID = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');

ALTER TABLE `transactions` ADD `default_currency` VARCHAR(50) NULL;
ALTER TABLE `transactions`  ADD `change_rate` float DEFAULT '1.00';

UPDATE `transactions` SET `default_currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');

ALTER TABLE `userdetails` ADD `preferred_currency` VARCHAR(60) NOT NULL DEFAULT 'USD';
UPDATE `userdetails` SET `preferred_currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');

ALTER TABLE `video_monetizations_withdrawals` ADD `currency` VARCHAR(50) NULL;
UPDATE `video_monetizations_withdrawals` SET `currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');
ALTER TABLE `video_monetizations_withdrawals` ADD `default_currency` VARCHAR(50) NULL;
UPDATE `video_monetizations_withdrawals` SET `default_currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');
ALTER TABLE `video_monetizations_withdrawals`  ADD `change_rate` float DEFAULT '1.00';

ALTER TABLE `orders` ADD `currency` VARCHAR(40) NOT NULL default 'USD';
UPDATE `orders` SET `currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');
ALTER TABLE `bankdetails` ADD `change_rate` FLOAT NOT NULL;
ALTER TABLE `bankdetails` ADD `default_currency` VARCHAR(40) NOT NULL default 'USD';
UPDATE `bankdetails` SET `default_currency` = (SELECT `value` from `settings` WHERE `name` = 'payment_default_currency');

INSERT INTO `tasks` (`task_id`, `type`, `started`, `start_time`, `timeout`, `priority`) VALUES (NULL, 'currency', '0', NULL, '3800', '1');