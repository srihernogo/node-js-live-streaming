CREATE TABLE `devices` (
  `device_id` int(11) UNSIGNED NOT NULL auto_increment,
  `owner_id` int(11) unsigned NOT NULL,
  `device_udid` varchar(255) NOT NULL,
  `push_token` varchar(255) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`device_id`),
  UNIQUE KEY `device_udid` (`device_udid`),
  KEY `device_udid_index` (`device_udid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

TRUNCATE TABLE `recently_viewed`;
ALTER TABLE `recently_viewed` DROP INDEX `unique`;
ALTER TABLE `recently_viewed` ADD UNIQUE `unique` (`ip`,`id`,`owner_id`,`type`);


ALTER TABLE `stories_user_settings` CHANGE `privacy` `privacy` VARCHAR(45) NOT NULL default 'public';
UPDATE `stories_user_settings` SET `privacy` = 'public' WHERE `stories_user_settings`.`privacy` = "0";
ALTER TABLE `stories` ADD `completed` TINYINT(1) NOT NULL DEFAULT '1';
ALTER TABLE `stories` ADD INDEX `completed` (`completed`);
ALTER TABLE `stories` ADD INDEX `status` (`status`);
ALTER TABLE `stories` ADD `title` VARCHAR(255) NOT NULL DEFAULT 'story' AFTER `story_id`;

INSERT IGNORE INTO `pages` ( `type`, `label`, `title`, `url`, `description`, `keywords`, `image`, `content`, `view_count`, `custom`, `banner_image`, `banner`) VALUES
( 'reel_create', 'Reel Create Page', 'Create Reel', NULL, '', '', NULL, NULL, 0, 0, 0, NULL),
( 'reel_view', 'Reel View Page', 'View Reel', NULL, '', '', NULL, NULL, 0, 0, 0, NULL),
( 'story_view', 'Story View Page', 'View Story', NULL, '', '', NULL, NULL, 0, 0, 0, NULL),
( 'reel_edit', 'Reel Edit Page', 'Edit Reel', NULL, '', '', NULL, NULL, 0, 0, 0, NULL);

DROP TABLE IF EXISTS `reels`;
CREATE TABLE `reels` (
  `reel_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `image` varchar(255) NOT NULL default '',
  `video_location` VARCHAR(255) NULL,
  `size` varchar(255) NULL,
  `tags` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `code` text NULL,
  `duration` varchar(50) NULL,
  `status` tinyint(1) NOT NULL default '1',
  `completed` tinyint(1) NOT NULL default '0',
  `view_privacy` VARCHAR(24) NOT NULL,
  `view_count` int(11) unsigned NOT NULL default '0',
  `comment_count` int(11) unsigned NOT NULL default '0',
  `like_count` int(11) unsigned NOT NULL default '0',
  `dislike_count` int(11) unsigned NOT NULL default '0',   
  `approve` tinyint NOT NULL default '1',
  `scheduled` VARCHAR(25) NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`reel_id`),
  KEY `view_privacy` (`view_privacy`),
  KEY `owner_id` (`owner_id`),
  KEY `approve` (`approve`),
  KEY `status` (`status`),
  KEY `scheduled` (`scheduled`),
  KEY `completed` (`completed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_unicode_ci;


INSERT IGNORE INTO `notificationtypes` ( `type`, `body`, `content_type`, `vars`) VALUES
( 'reels_processed_complete', 'We have completed processing your {reels}.', 'reels', '{\"reels\":\"reel\"}'),
( 'reels_processed_failed', 'We are having trouble processing to your {reels}.', 'reels', '{\"reels\":\"reel\"}'),
( 'reels_comment', '{subject} commented on your {reels} {comment_title}.', 'reels', '{\"reels\":\"reel\"}'),
( 'reels_reply_comment', '{subject} replied to your {comment} on your {reels} {reply_title}', 'reels', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels_comments_like', '{subject} likes your {comment} on your {reels} {comment_title}.', 'reels', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels_comments_dislike', '{subject} dislike your {comment} on your {reels} {comment_title}.', 'reels', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels_reply_like', '{subject} likes your {reply} on {comment} {reply_title}.', 'reels', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'reels_reply_dislike', '{subject} dislike your {reply} on {comment} {reply_title}.', 'reels', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'reels_like', '{subject} likes your {reels}.', 'reels', '{\"reels\":\"reel\"}'),
( 'reels_dislike', '{subject} dislike your {reels}.', 'reels', '{\"reels\":\"reel\"}'),
( 'stories_processed_complete', 'We have completed processing your {stories}.', 'stories', '{\"stories\":\"story\"}'),
( 'stories_processed_failed', 'We are having trouble processing to your {stories}.', 'stories', '{\"stories\":\"story\"}'),
( 'stories_like', '{subject} likes your {stories}.', 'stories', '{\"stories\":\"story\"}'),
( 'stories_dislike', '{subject} dislike your {stories}.', 'stories', '{\"stories\":\"story\"}'),
( 'reels_create', 'Uploaded new Reel', 'default', '{}'),
( 'stories_create', 'Uploaded new Story', 'default', '{}'),
( 'stories_comment', '{subject} commented on your {stories} {comment_title}.', 'story', '{\"stories\":\"story\"}'),
( 'stories_reply_comment', '{subject} replied to your {comment} on your {stories} {reply_title}', 'stories', '{\"stories\":\"story\",\"comment\":\"comment\"}'),
( 'stories_comments_like', '{subject} likes your {comment} on your {stories} {comment_title}.', 'stories', '{\"stories\":\"story\",\"comment\":\"comment\"}'),
( 'stories_comments_dislike', '{subject} dislike your {comment} on your {stories} {comment_title}.', 'stories', '{\"story\":\"reel\",\"comment\":\"comment\"}'),
( 'stories_reply_like', '{subject} likes your {reply} on {comment} {reply_title}.', 'stories', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'stories_reply_dislike', '{subject} dislike your {reply} on {comment} {reply_title}.', 'stories', '{\"comment\":\"comment\",\"reply\":\"reply\"}');

INSERT IGNORE INTO `emailtemplates` ( `content_type`, `type`, `vars`) VALUES
( 'reels', 'reels_processed_complete', '{\"reels\":\"reel\"}'),
( 'reels', 'reels_processed_failed', '{\"reels\":\"reel\"}'),
( 'reels', 'reels_comment', '{\"reels\":\"reel\"}'),
( 'reels', 'reels_reply_comment', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels', 'reels_comments_like', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels', 'reels_comments_dislike', '{\"reels\":\"reel\",\"comment\":\"comment\"}'),
( 'reels', 'reels_reply_like', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'reels', 'reels_reply_dislike', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'reels', 'reels_like', '{\"reels\":\"reel\"}'),
( 'reels', 'reels_dislike', '{\"reels\":\"reel\"}'),
( 'stories', 'stories_processed_failed', '{\"stories\":\"story\"}'),
( 'stories', 'stories_processed_failed', '{\"stories\":\"story\"}'),
( 'stories', 'stories_like', '{\"stories\":\"story\"}'),
( 'stories', 'stories_dislike', '{\"stories\":\"story\"}'),
( 'stories', 'stories_comment', '{\"stories\":\"story\"}'),
( 'stories', 'stories_reply_comment', '{\"stories\":\"story\",\"comment\":\"comment\"}'),
( 'stories', 'stories_comments_like', '{\"stories\":\"story\",\"comment\":\"comment\"}'),
( 'stories', 'stories_comments_dislike', '{\"stories\":\"story\",\"comment\":\"comment\"}'),
( 'stories', 'stories_reply_like', '{\"comment\":\"comment\",\"reply\":\"reply\"}'),
( 'stories', 'stories_reply_dislike', '{\"comment\":\"comment\",\"reply\":\"reply\"}');

INSERT IGNORE INTO `tasks` ( `type`, `started`, `start_time`, `timeout`, `priority`) VALUES
('reelsVideoEncode',0,NULL,15,1),
('storiesVideoEncode',0,NULL,15,1);


INSERT IGNORE INTO `settings` (`name`, `value`) VALUES
  ("enable_reels",'1'),
  ("reel_comment",'1'),
  ("reel_comment_like",'1'),
  ("reel_comment_dislike",'1'),
  ("reel_video_upload",'10'),
  ("reel_like",'1'),
  ("reel_dislike",'1'),
  ("story_like",'1'),
  ("story_dislike",'1');


INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'delete' as `name`,
    2 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'delete' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'edit' as `name`,
    2 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'edit' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

  INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'view' as `name`,
    2 as `value`
  FROM `levels` WHERE `type` IN('admin');
INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'view' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator');

INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'reels' as `type`,
    'create' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator','admin');
