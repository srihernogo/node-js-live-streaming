CREATE TABLE `gifts` (
  `gift_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `image` varchar(255) NOT NULL,
  `approve` tinyint(1) NOT NULL DEFAULT '1',
  `used` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `creation_date` datetime NOT NULL,
   PRIMARY KEY (`gift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT IGNORE INTO `notificationtypes` ( `type`, `body`, `content_type`, `vars`) VALUES
( 'gift', '{subject} sent you a gift on {videos}.', 'default', '{\"videos\":\"video\"}');

INSERT IGNORE INTO `emailtemplates` ( `content_type`, `type`, `vars`) VALUES
( 'default', 'gift', '{\"videos\":\"video\"}');

INSERT INTO `settings` (`name`, `value`) VALUES
  ("logo_type",'0');

INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'gifts' as `type`,
    'allow' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator','admin');

  ALTER TABLE `transactions` ADD `tip_id` INT(11) NOT NULL default 0;


INSERT INTO `settings` (`name`, `value`) VALUES
('banktransfer_payout','Account Name:
Account Number:
Bank Name:
Branch Address of Bank:
IFSC Code:'),
('payout_settings','paypal'),
('audio_sell','1'),
('audio_commission_type','1'),
('audio_commission_value','0');

ALTER TABLE `video_monetizations_withdrawals` ADD `type` VARCHAR(100) NOT NULL DEFAULT 'paypal',ADD `bank_transfer` TEXT NULL;
ALTER TABLE `users` ADD `payoutType` VARCHAR(50) NOT NULL DEFAULT 'paypal';
ALTER TABLE `users` ADD `bank_transfer` TEXT NULL;

-- new
ALTER TABLE `audio` ADD `price` VARCHAR(255) NOT NULL DEFAULT '0';
ALTER TABLE `audio` ADD `purchase_count` INT(11) UNSIGNED NOT NULL AFTER `price`;
ALTER TABLE `audio`  ADD `total_purchase_amount` varchar(255) NOT NULL DEFAULT 0;

INSERT IGNORE INTO `notificationtypes` ( `type`, `body`, `content_type`, `vars`) VALUES
(  'audio_purchased','Thanks for purchasing {audio}.','audio', '{\"audio\":\"audio\"}'),
(  'audio_purchased_owner','Your {audio} is purchased by {subject}.','audio', '{\"audio\":\"audio\"}');

INSERT IGNORE INTO `emailtemplates` ( `content_type`, `type`, `vars`) VALUES
( 'audio', 'audio_purchased', '{\"audio\":\"audio\"}'),
( 'audio', 'audio_purchased_owner', '{\"audio\":\"audio\"}');

INSERT IGNORE INTO `level_permissions`
  SELECT
    level_id as `level_id`,
    'audio' as `type`,
    'sell_audios' as `name`,
    1 as `value`
  FROM `levels` WHERE `type` IN('user','moderator','admin');

